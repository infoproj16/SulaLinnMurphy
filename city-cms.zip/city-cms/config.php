<?php
	$dbUser = "hourcade";
	$dbPassword = "Z4H7yorrKWW3";
	$dbName = "db_hourcade";
	$dbHost = "dbdev.cs.uiowa.edu";
	$adminEmail = "juanpablo-hourcade@uiowa.edu";
	$baseURL = "http://webdev.divms.uiowa.edu/~hourcade/phpdb";
	
	// you should probably set up a table where you enter this info
	$siteName = "Soccer Lover's Club";
	$footerText = "Copyright &copy; 2016 Soccer Lover's Club"
?>